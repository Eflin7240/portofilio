const text = document.querySelector(".sec-taxt");
const textLoad = () => {
    setTimeout(() => {
        text.textContent = "Frontand developer";
    }, 0);
}

textLoad();